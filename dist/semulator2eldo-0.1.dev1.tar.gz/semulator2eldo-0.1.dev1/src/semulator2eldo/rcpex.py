#!/usr/bin/env python
# -*-coding:utf-8 -*-
'''
@File    :   rcpex.py
@Time    :   2021/12/17 15:33:41
@Author  :   Paul Amari 

Process RCPEX inputs and outputs from Semulator3D
'''
import os
import os.path as op
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import semulator2eldo.utils as utils
# import semulator2eldo.data as sd


class SemProject:
    def __init__(self,
                 name,
                 simulation_dir='C:\\Users\\PA266310\\Documents\\3-Simulation',
                 process_version='1.03'):
        self.name = name
        self.simulation_dir = simulation_dir
        self.process_version = process_version
        # Set useful directories
        self.project_dir = op.join(simulation_dir, name)
        self.sem_output_dir = op.join(self.project_dir, 'semulator_outputs')
        self.create_dirs()
        # Set useful path
        self.parameters_fpath = op.join(
            self.project_dir, 'databases', 'simulation_databases.xlsx')
        self.outputs_fpath = op.join(
            self.sem_output_dir, ("%s_RCPEX_outputs.xlsx") % (name))
        self.manual_outputs_fpath = op.join(
            self.sem_output_dir, ("%s_RCPEX_OutputsResults.xlsx") % (name))
        # Load cpex from xlsx file
        self.load_params()
        self.load_param_cpex()

    def create_dirs(self):
        for directory in [
                getattr(self, d) for d in self.__dict__ if 'dir' in d]:
            if not op.isdir(directory):
                os.mkdir(directory)

    # Getters
    def get_analyze_dir(self):
        return self.project_dir

    def get_sem_output_dir(self):
        return self.sem_output_dir

    def get_figures_dir(self):
        return self.sem_output_dir

    def load_params(self, version_filtering=True):
        '''
        Load data from parameters_fpath xlsx file in a df with the appropriate version.
        '''
        df = pd.read_excel(self.parameters_fpath,
                           sheet_name='semulator_outputs', skiprows=1)
        # Update df with additional parameters
        df['blsl_length_y'] = 2*(df['wf'] + df['lg'])
        df['wl_length_y'] = df['periph_length_y'] + df['blsl_number_y']*df['blsl_length_y']

        if version_filtering:
            self.params_df = df[df['process_version']
                                == self.process_version].copy()
        else:
            self.params_df = df

    def load_param_cpex(self):
        '''
        Load data from parameters_fpath xlsx file with columns of interest for cpex
        '''
        columns = [
            'run', 'layout_top_cell', 'resolution', 'lower_corner_x',
            'lower_corner_y', 'upper_corner_x', 'upper_corner_y', 'cpex',
            'blsl_number_y', 'wl_length_y']
        self.param_cpex_df = self.params_df[columns].copy()
        self.param_cpex_df.dropna(subset=['cpex'], inplace=True)

    def load_outputs_rpex(self):
        '''
        Load data from outputs_fpath xlsx file with columns of interest for cpex
        '''
        self.param_rpex_df = pd.read_excel(
            self.outputs_fpath, sheet_name="RPEX", skiprows=0, index_col=0)

    def load_expeditor_outputs(self):
        '''
        Load data from expeditor sheet in parameters_fpath xlsx file. 
        '''
        df = pd.read_excel(self.parameters_fpath,
                           sheet_name='expeditor', skiprows=1)
        self.expeditor_df = df


# Subclass
class Metrology(SemProject):
    '''

    '''

    def __init__(self, run, sem_project):
        self.run = run
        self.fname = ('%s_metrology.txt') % (run)
        self.fpath = op.join(sem_project.sem_output_dir, self.fname)

    def _parse_line(self, line, parameter_name):
        split_line = line.split()
        label = split_line[0][len(parameter_name):].replace('_Unlabeled', '')
        nodes = split_line[0].replace('_Unlabeled', '').split('_')[1:]
        value = float(split_line[-1][:-1])
        node1 = nodes[0]
        node2 = nodes[1 % len(nodes)]
        return label, node1, node2, value

    def capa_to_df(self):
        '''
        Convert a metrology file from a specific run into a DataFrame for easier use.
        '''
        # Read lines in metrology.txt file
        parameter_name = 'C_'
        with open(self.fpath) as f:
            lines = f.readlines()
        labels = []
        node1_ls = []
        node2_ls = []
        values = []
        for line in lines:
            parameters = self._parse_line(line, parameter_name)
            if line[:len(parameter_name)] == parameter_name and 'e' not in parameters[2]:
                labels.append(parameters[0])
                node1_ls.append(parameters[1])
                node2_ls.append(parameters[2])
                values.append(parameters[3])
        # Create dataframe
        self.capa_df = pd.DataFrame({'C_Label': labels,
                                     'Net1': node1_ls,
                                     'Net2': node2_ls,
                                     'C_Value': values})

    def resistance_to_df(self):
        '''
        Retrieve resistance to analyze unit cell resistance contribution
        '''
        # Resistance labels to look for
        r_names = ['R_P_', 'R_tot_', 'R_uc_', 'R_CA_P_', 'R_PCA_P_']
        runs = []
        nodes = []
        r_labels = []
        cell_number_ls = []
        r_values = []
        input_nodes = []
        output_nodes = []
        # Read metrology.txt file
        with open(self.fpath) as f:
            line = f.readline()
            while line:
                for r_name in r_names:
                    if r_name in line:
                        input_node = line[line.find('WL'): line.find(
                            'WL', line.find('WL') + 1) - 1]
                        output_node = line[line.find(
                            'WL', line.find('WL')+1): line.find(' = ')]
                        r_label = r_name[:-1]
                        r_value = self.parse_line_value(line)
                        node = input_node[0:3]
                        # Specific parsing for run Column_10X1BL1SL
                        if 'uc' in r_name:
                            first_l = int(
                                line[line.find('Int_L')+5: line.find('_WL', line.find('Int_L'))])
                            last_l = int(
                                line
                                [line.find(
                                    'Int_L', line.find('Int_L') + 1) +
                                 5: line.find(' = ')])
                            cell_number = last_l - first_l
                        elif 'tot' in r_name:
                            cell_number = 9
                        else:
                            cell_number = 0
                        # Append values to a list
                        runs.append(self.run)
                        nodes.append(node)
                        r_labels.append(r_label)
                        cell_number_ls.append(cell_number)
                        r_values.append(r_value)
                        input_nodes.append(input_node)
                        output_nodes.append(output_node)
                line = f.readline()
        # Create a buffer df to append
        self.resistance_df = pd.DataFrame({'Layout': runs,
                                           'Net': nodes,
                                           'R_Label': r_labels,
                                           'Cell_Number': cell_number_ls,
                                           'R_Value': r_values,
                                           'Port_In': input_nodes,
                                           'Port_Out': output_nodes})
        # Compute resistance per unit cell
        # for idx in self.resistance_df.index:
        #     se = self.resistance_df.loc[idx]
        #     if se.R_Label == 'R_uc':
        #         self.resistance_df.at[idx, 'R_u_value'] = se.R_Value / se.Cell_Number
        return self.resistance_df

    def parse_line_value(self, line):
        '''
        Parse value at the end of the line of a metrology.txt file
        '''
        value = float(line.split(' ')[-1][:-1])
        return value


class MetrologyMatrix(SemProject):
    def __init__(self, run, sem_project):
        self.run = run
        self.fname = ('%s_metrologyMatrices.csv') % (run)
        self.fpath = op.join(sem_project.sem_output_dir, self.fname)
        self.project_dir = sem_project.project_dir
        self.sem_output_dir = sem_project.sem_output_dir
        self.create_matrix_df()
        self.create_matrix_np()

    def create_matrix_df(self):
        self.capa_df = pd.read_csv(self.fpath, skiprows=1)
        for column in self.capa_df.columns:
            if 'Unnamed' in column:
                self.capa_df.drop([column], axis=1, inplace=True)
            else:
                new_column = column.replace('_Unlabeled', '')
                self.capa_df.rename(
                    {column: new_column},
                    axis='columns', inplace=True)
        for idx in self.capa_df.index:
            net = self.capa_df.at[idx, 'Net_Names']
            if 'e' != net[:1]:
                new_net = net.replace('_Unlabeled', '')
                self.capa_df.at[idx, 'Net_Names'] = new_net
            else:
                self.capa_df.drop([idx], axis=0, inplace=True)
        # Reindex df with the column Net_Names
        self.capa_df.set_index(['Net_Names'], inplace=True)
        # return self.capa_df

    def create_matrix_np(self):
        self.capa_matrix_np, self.net_names = self.df_to_np(self.capa_df)

    # def df_to_np(self, matrix_df):
    #     self.capa_matrix_np = self.capa_df.to_numpy()
    #     self.net_names = self.capa_df.columns

    def df_to_np(self, df):
        matrix_np = df.to_numpy()
        labels = list(df.columns)
        return matrix_np, labels

    def plot_matrix(self, save_fig=False, fig_extensions=['.png']):
        '''
        Plot capacitance matrix in a colormap to identify highest capacitance value
        '''
        # Create np array in case it has not been created yet.
        if not hasattr(self, 'capa_matrix_df'):
            self.df_to_np(self.capa_df)

        # Create subplots
        fig, ax = plt.subplots(1, 1, figsize=(5, 5))

        # Plot
        im = ax.imshow(
            np.log10(np.abs(self.capa_matrix_np)),
            cmap='bwr', vmax=-2, vmin=-12)

        # General ax settings
        ax.grid(which='minor', color='white', linestyle='-', linewidth=1)
        ax.set_axisbelow(True)
        # Major ticks settings
        ax.set_xticks(np.arange(len(self.net_names)))
        ax.set_yticks(np.arange(len(self.net_names)))
        # ... and label them with the respective list entries
        ax.set_xticklabels(self.net_names)
        ax.set_yticklabels(self.net_names)
        # Minor ticks
        ax.set_xticks(ax.get_xticks() + 0.5, minor=True)
        ax.set_yticks(ax.get_yticks() + 0.5, minor=True)
        # Let the horizontal axes labeling appear on top.
        ax.tick_params(top=True, bottom=False,
                       labeltop=True, labelbottom=False)
        # Rotate the tick labels and set their alignment.
        plt.setp(ax.get_xticklabels(), rotation=90, ha="left",
                 va="center", rotation_mode="anchor")

        # create an axes on the right side of ax. The width of cax will be 5%
        # of ax and the padding between cax and ax will be fixed at 0.05 inch.
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.05)
        cbar = plt.colorbar(im, cax=cax, label='|C| (pF)')
        cbar.set_ticks([k for k in range(-2, -14, -2)])
        cbar.set_ticklabels([('$10^{%d}$') % (k) for k in range(-2, -14, -2)])
        fig.tight_layout()

        # Save or plot data
        fig_name = ('%s_CapaMatrixPlot') % (self.run)
        fig_fpath = op.join(self.sem_output_dir, fig_name)
        utils.plot_save_fig(fig_fpath, fig_extensions, save_fig, 300)

    def create_sub_matrix_df(self, sub_nodes):
        '''
        Create a submatrix containing only capacitances from nodes in sub_nodes 
        '''
        # Create df in case it has not been created yet.
        if not hasattr(self, 'capa_matrix_df'):
            self.create_matrix_df()
        # Create new dataframe with columns in nodes
        df = self.capa_df[sub_nodes]
        # Create new dataframe with index in nodes
        self.sub_capa_matrix_df = df[df.index.isin(sub_nodes)]
        del df

    def create_sub_matrix_np(self, sub_nodes):
        # Create df in case it has not been created yet.
        if not hasattr(self, 'sub_capa_matrix_df'):
            self.create_sub_matrix_df(sub_nodes)
        # Create sub matrix of capacitance
        self.sub_capa_matrix_np, _ = self.df_to_np(self.sub_capa_matrix_df)
