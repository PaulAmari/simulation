# semulator2eldo package

This is a simple example package for learning purpose.
./docs/                 documentation
./scripts/              top-level scripts
./src/semulator2eldo/        the main package with the source code
./src/semulator2eldo/test    unit tests

│   .gitignore
│   CHANGES.txt
│   LICENSE.txt
│   pyproject.toml
│   README.md
│   requirements.txt
│   setup.cfg
│
├───dist
│       semulator2eldo-0.1.dev1-py3-none-any.whl
│       semulator2eldo-0.1.dev1.tar.gz
│
├───docs
├───scripts
└───src
    ├───semulator2eldo
    │   │   data.py
    │   │   eldo_extract.py
    │   │   netlist.py
    │   │   rcpex.py
    │   │   utils.py
    │   │   __init__.py
    │   │
    │   ├───test
    │   │       test_main.py
    │   │       __init__.py
    │   │
    │   └───__pycache__
    │           data.cpython-38.pyc
    │           data_management.cpython-38.pyc
    │           eldo_extract.cpython-38.pyc
    │           netlist.cpython-38.pyc
    │           rcpex.cpython-38.pyc
    │           utils.cpython-38.pyc
    │           __init__.cpython-38.pyc
    │
    └───semulator2eldo.egg-info
            dependency_links.txt
            PKG-INFO
            SOURCES.txt
            top_level.txt