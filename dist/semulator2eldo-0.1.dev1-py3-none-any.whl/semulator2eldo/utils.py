#!/usr/bin/env python
# -*-coding:utf-8 -*-
'''
@File    :   utils.py
@Time    :   2021/12/17 15:33:28
@Author  :   Paul Amari 
'''

import os
import os.path as op
import shutil
import re
import string
import matplotlib.pyplot as plt


def replace_fname(fpath, old, new):
    """Replace old string by new string in a filename given its filepath.

    Args:
        fpath ([type]): [description]
        old ([type]): [description]
        new ([type]): [description]

    Returns:
        [type]: [description]
    """
    fdir, fname = op.split(fpath)
    new_fname = fname.replace(old, new)
    new_fpath = op.join(fdir, new_fname)
    return new_fpath


def search_files_suffix(directory='.', suffix=''):
    '''
    Search recursively files with a specific suffix in a directory.
    '''
    suffix = suffix.lower()
    fpaths = []
    for dirpath, dirnames, files in os.walk(directory):
        for name in files:
            if suffix and name.lower().endswith(suffix):
                fpaths.append(os.path.join(dirpath, name))
            elif not suffix:
                fpaths.append(os.path.join(dirpath, name))
    return fpaths


def copy_with_treeview(source_dir, source_fpath, destination_dir):
    '''
    Copy file from source_fpath to destination_fpath 
    with the same treeview starting from source_dir.
    source_dir          = 'C:\\source'
    source_fpath        = 'C:\\source\\some_directory\\some_file.txt'
    destination_dir     = 'C:\\destination'
    destination_fpath   = 'C:\\destination\\some_directory\\some_file.txt'
    '''
    source_treeview = source_fpath.split('\\')
    # Join all directories inside source_dir to destination_dir
    for dirfile in source_treeview[len(source_dir.split('\\')):-1]:
        destination_fpath = op.join(destination_dir, dirfile)
    if not op.isdir(destination_fpath):
        os.makedirs(destination_fpath)
    shutil.copy(source_fpath, destination_fpath)


def alphabet(case='upper'):
    '''
    Return a list of the alphabet in lower or upper case.
    '''
    if case == 'upper':
        return list(string.ascii_uppercase)
    elif case == 'lower':
        return list(string.ascii_lowercase)


def plot_save_fig(fpath, extensions=['.png'], save=False, dpi=200):
    '''
    Plot or save data depending on save option
    '''
    if save:
        fig_dir = op.split(fpath)[0]
        # Create directories if they do not already exist
        if not op.isdir(fig_dir):
            os.makedirs(fig_dir)
        # Save figure for different extensions
        for extension in extensions:
            plt.savefig(fpath + extension, dpi=dpi)
    else:
        plt.show()


def get_colors(label='tab10'):
    # Import colors from tab20 qualitative colormaps
    # https://matplotlib.org/stable/tutorials/colors/colormaps.html
    if label == 'tab10':
        return list([plt.cm.tab10(i) for i in range(10)])
    elif label == 'tab20':
        return list([plt.cm.tab20(i) for i in range(20)])


def findall_pattern(pattern, line):
    """Parse line with a regex pattern in line

    Args:
        pattern (string): Regular expression
        line (string): Text to parse with regex

    Returns:
        list: Contains the outputs of the regex search
    """
    pattern_regex = re.compile(pattern)
    return pattern_regex.findall(line)


def test_function():
    print('this is a test.')
