#!/usr/bin/env python
# -*-coding:utf-8 -*-
'''
@File    :   data.py
@Time    :   2021/12/17 13:25:49
@Author  :   Paul Amari

Organize inputs and outputs data from the whole simulation project with a specific fil structure.
'''

import os
import os.path as op
import pandas as pd
import xlwings as xw
import semulator2eldo.utils as utils

# Close the xlsx file but it is longer to run !
# app = xw.App(visible=False)


class Project:
    """[summary]
    """

    def __init__(self,
                 simulation_dir,
                 name
                 ):
        self.name = name
        self.simulation_dir = simulation_dir
        self.main_dir = op.join(simulation_dir, name)
        self.sub_dirs = ('databases',
                         'semulator_outputs',
                         'expeditor_outputs',
                         'eldo_inputs',
                         'eldo_outputs')
        self.database_fpath = op.join(
            self.main_dir, 'databases', 'simulation_databases.xlsx')

        if not op.isdir(self.main_dir):
            self.initiate_file_structure()

        self.add_ios()

    def initiate_file_structure(self):
        for directory in self.sub_dirs:
            print(op.join(self.main_dir, directory))
            os.makedirs(op.join(self.main_dir, directory))
        self.initiate_db()

    def initiate_db(self):
        wb = xw.Book()
        # Add sheet of interest to record simulation parameters.
        sheet_names = ('semulator_outputs',
                       'eldo_inputs',
                       'eldo_outputs',
                       'expeditor_outputs')
        for sheet_name in sheet_names:
            wb.sheets.add(sheet_name)
            sheet = wb.sheets[sheet_name]
            # Need to implement the sheet headers
            sheet.range('A1').value = 'Hello'
        wb.sheets['Feuil1'].delete()
        wb.save(self.database_fpath)
        wb.close()

    def add_ios(self):
        """
        Add inputs and outputs objects from sub_dirs
        """
        for sub_dir in self.sub_dirs[1:]:
            setattr(self, sub_dir, IO(self.main_dir, sub_dir))

    def add_new_attr(self, attribute):
        setattr(self, attribute, attribute)

    def get_main_dir(self):
        return self.main_dir

    def get_sub_dirs(self):
        return self.sub_dirs


class IO:
    """
    Inputs/Outputs of the simulation.
    Each IO has its own :
    - directory in main_dir 
    - sheet in database_fpath
    """

    def __init__(self, main_dir, name):
        self.main_dir = main_dir
        self.name = name
        self.directory = op.join(main_dir, name)
        self.database_fpath = op.join(
            self.main_dir, 'databases', 'simulation_databases.xlsx')
        # Initialize an empty dictionary for parameter's unit in df
        self.load_df_units()
        self.load_df()

    def load_df(self):
        """
        Load DataFrame from the IO sheet in database_fpath
        """
        self.df = pd.read_excel(self.database_fpath,
                                sheet_name=self.name, skiprows=1, index_col=0)

    def load_df_units(self):
        """
        Load a dictionary with units of the parameters in the IO sheet
        """
        self.df_units = {}
        # Load sheet from workbook
        sheet = xw.Book(self.database_fpath).sheets[self.name]
        n_columns = last_column_id(sheet)

        for letter in utils.alphabet()[1:n_columns]:
            unit = sheet.range(letter + '1').value
            if unit:
                parameter = sheet.range(letter + '2').value
                self.df_units[parameter] = unit

    def update_db(self, row):
        """Insert new row at the end of the IO sheet of database_fpath

        Args:
            row (dict): data to update in db
        """
        if row['run'] in self.df.run.to_list():
            print('Warning : The eldo_inputs sheet has not been updated.')
            print('The run below already exists in database :')
            print(row['run'])
            print('Change input parameters to have a different netlist run.\n')
        else:
            insert_into(self.database_fpath, self.name, row)


def last_column_id(sheet):
    """
    Get the last column index with data without interruption between columns
    """
    return sheet.range('B2').end('right').column


def insert_into(fpath, sheet_name, row):
    """
    Insert a new row at the end of the sheet from the workbook
    """
    # Load sheet from workbook
    wb = xw.Book(fpath)
    sheet = wb.sheets(sheet_name)
    # Get the last row with data without interruption between rows
    n_rows = sheet.range('A2').end('down').row
    next_id = sheet.range(('A%d') % (n_rows)).value + 1
    sheet.range(('A%d') % (n_rows+1)).value = next_id
    sheet.range(('B%d:C%d') % (n_rows+1, n_rows+1)).value = list(row.values())
    wb.save()
