#!/usr/bin/env python
# -*-coding:utf-8 -*-
'''
@File    :   eldo_extract.py
@Time    :   2021/12/17 15:36:20
@Author  :   Paul Amari 

Parse and analyze extract from eldo
'''


import os.path as op
import pandas as pd
import semulator2eldo.utils as utils

PATTERN_PARAM = '(?<=PARAM\s)(.*)(?=\s=\s)\s=\s*(.*)'
PATTERN_EXTRACT = '\s{4,4}\*(?<=\s{4,4}\*)(\w{3,5}\d)_([A-Z0-9]*)_(\w*)(?=\s=\s)\s=\s*(.*\d)\s*'


def find_params(fpath):
    """Find all parameters PARAM varying into an eldo_output extract file.
    Each set of parameters begins by : TITLE ***
    The function look for PARAM only in the first set of parameters. 

    Args:
        fpath (string): Fullpath of the eldo_output extract file

    Returns:
        list: Parameters found in fpath
    """
    params = []
    with open(fpath, 'r') as f:
        for k, line in enumerate(f):
            param_label, _ = parse_param_line(line)
            if param_label:
                params.append(param_label)
            # Break the for loop when entering into a new set of parameters
            if k > 1 and 'TITLE ***' in line:
                break
    return params


def parse_extract_file(fpath, param_df, extract_df):
    """Parse the extract output file from eldo into DataFrames.

    Args:
        fpath (string): Fullpath of the file to parse
        param_df (DataFrame): PARAM varying in eldo simulation
        extract_df (DataFrame): EXTRACT outputs from eldo simulation
    """
    param_count = 0
    extract_count = 0
    with open(fpath, 'r') as f:
        for line in f:
            # Regex for eldo PARAM label and its value
            param_label, param_value = parse_param_line(line)
            if param_label:
                param_id = param_count // len(param_df.columns)
                param_df.at[param_id, param_label] = param_value
                param_count += 1

            # Regex for eldo label and extract value
            findall_extract = utils.findall_pattern(PATTERN_EXTRACT, line)
            if findall_extract:
                extract_df.loc[extract_count] = [
                    param_id] + list(findall_extract[0])
                extract_count += 1


def parse_param_line(line, str_params=['pat_set', 'pat_reset']):
    """Parse a line to retrieve PARAM varied in an eldo_output extract file 
    with PATTERN_PARAM using regular expression.

    Args:
        line (string): Line to parse

    Returns:
        string: Label of PARAM, '' if PATTERN_PARAM does not match
        float: Value of PARAM, NaN if PATTERN_PARAM does not match
    """
    findall_param = utils.findall_pattern(PATTERN_PARAM, line)
    if findall_param:
        param_label = str.lower(findall_param[0][0])
        if param_label in str_params:
            param_value = findall_param[0][1]
        else:
            param_value = float(findall_param[0][1])
    else:
        param_label = ''
        param_value = float('NaN')
    return param_label, param_value


def load_dfs(project, idx, drop_columns=[]):
    """Load extract.csv and extract_param.csv files as a DataFrame from an 
    eldo_outputs run specified by project and idx.

    Args:
        project (Project): semulator2eldo project to consider
        idx (integer): index of the run in eldo_outputs sheet

    Returns:
        DataFrame: PARAM varied in eldo_outputs run 
        DataFrame: EXTRACT from eldo_outputs run
    """
    run = project.eldo_outputs.df.at[idx, 'run']
    param_fpath = op.join(project.eldo_outputs.directory,
                          run + '_extract_param.csv')
    param_df = pd.read_csv(param_fpath, index_col=0,
                           dtype={'pat_set': str, 'pat_reset': str})
    param_df.drop(columns=drop_columns, inplace=True)
    extract_fpath = op.join(project.eldo_outputs.directory,
                            run + '_extract.csv')
    extract_df = pd.read_csv(extract_fpath, index_col=0)
    return param_df, extract_df
